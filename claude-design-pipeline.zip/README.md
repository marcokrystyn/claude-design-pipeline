# Claude Design Pipeline

GitHub workspace for a Claude Chat → prompt → Claude Design workflow.

## Workflow

1. Claude Chat receives a design request.
2. Claude converts it into a structured design prompt.
3. The prompt is saved in `prompts/pending/`.
4. A design-capable Claude workflow reads the pending prompt.
5. The resulting design is saved in `designs/`.
6. The prompt is moved to `prompts/completed/`.

## Folders

- `prompts/pending/` — prompts ready for Design Creator
- `prompts/approved/` — prompts manually approved for generation
- `prompts/completed/` — processed prompts
- `designs/` — generated/exported design files
- `instructions/` — workflow rules and design system

## Important

GitHub is the shared workspace. It does not itself press buttons or invoke Claude Design automatically. The exact automation depends on the Claude feature/interface connected to this repository.

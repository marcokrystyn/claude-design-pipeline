# Design System

Use this file as the persistent design-generation standard.

## General quality

- Premium, polished and intentional visual hierarchy.
- Avoid generic AI-looking layouts.
- Prefer strong typography, spacing and composition.
- Every element should have a clear purpose.
- Keep the visual language consistent across related designs.

## Prompt structure

Every generated prompt should specify, when relevant:

1. Objective
2. Subject
3. Audience
4. Composition
5. Layout
6. Visual style
7. Color system
8. Typography
9. Lighting
10. Materials/textures
11. Background/environment
12. Camera/perspective
13. Responsive behavior
14. Technical constraints
15. Negative constraints

## Output

The final prompt must be directly usable by the Claude design-generation workflow without additional explanation.
